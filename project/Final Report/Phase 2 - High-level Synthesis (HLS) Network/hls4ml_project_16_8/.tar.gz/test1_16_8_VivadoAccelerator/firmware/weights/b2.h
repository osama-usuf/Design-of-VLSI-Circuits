//Numpy array shape [10]
//Min -0.425380170345
//Max 0.408823728561
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[10];
#else
model_default_t b2[10] = {-0.01825608, -0.16215770, 0.09086807, -0.09078512, -0.16150288, 0.40310800, -0.42538017, 0.40882373, 0.40011007, 0.26858842};
#endif

#endif

//Numpy array shape [10]
//Min -0.580672025681
//Max 0.746558189392
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[10];
#else
model_default_t b4[10] = {-0.36216861, 0.74655819, 0.16842903, -0.25879353, -0.06869052, 0.60821271, -0.25036645, 0.17312479, -0.58067203, -0.32980222};
#endif

#endif
